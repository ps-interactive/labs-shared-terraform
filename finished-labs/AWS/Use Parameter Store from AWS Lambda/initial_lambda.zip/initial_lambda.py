

def print_credentials(credentials):
    for parameter in credentials['Parameters']:
        print('Name: {0[Name]:s}, Value: {0[Value]}, Type: {0[Type]:s}'.format(parameter))

def handler(event, context):
    print(80*"*")
    print("Hello World")
    print(80*"*")

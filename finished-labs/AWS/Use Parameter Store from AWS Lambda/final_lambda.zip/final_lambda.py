import boto3

def print_credentials(credentials):
    for parameter in credentials['Parameters']:
        print('Name: {0[Name]:s}, Value: {0[Value]}, Type: {0[Type]:s}'.format(parameter))

def handler(event, context):
    client = boto3.client('ssm')
    credentials = client.get_parameters_by_path(Path=event['path'], Recursive=True, WithDecryption=True)
    print(80*"*")
    print_credentials(credentials)
    print(80*"*")

const dynamodb = require('aws-sdk/clients/dynamodb')
const docClient = new dynamodb.DocumentClient();

// add validation function code: TODO

exports.handler = async (event) => {
    
    console.log(event)

    const raw_input = JSON.parse(event.body)

    // calling validation function: TODO
    
    
    // preparing the paramters for DynamoDB put operation
        const params = {
            TableName : process.env.TABLE_NAME,
            Item: { 
                orderId: raw_input.orderId, 
                price: raw_input.price,
                quantity: raw_input.quantity,
                payment_mode: raw_input.payment_mode
            }
        };
    
        const result = await docClient.put(params).promise();

        return "Success"  
};

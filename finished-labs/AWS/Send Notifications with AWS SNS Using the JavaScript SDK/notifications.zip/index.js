exports.handler = (event) => {
  const notification = event.Records[0].Sns;
  const { Message } = notification;

  console.log(`Message received: ${JSON.stringify(Message)}`);
};

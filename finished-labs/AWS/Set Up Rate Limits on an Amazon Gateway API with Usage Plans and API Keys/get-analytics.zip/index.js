exports.handler = async (event) => {

    const status = ["PENDING", "PROCESSED", "CANCELLED"];

    let sampleData;
    const dataset = [];

    for (let i = 0; i < 10; i++) {
        sampleData = {
            "date": Date.now(),
            "userid": `${Math.random().toString(36).substring(7)}_${Math.random().toString(36).substring(7)}`,
            "hits": Math.floor(Math.random() * (100 - 10)) + 10,
            "status": status[Math.floor(Math.random() * status.length)]
        }

        dataset.push(sampleData);
    }

    return {
        statusCode: 200,
        body: JSON.stringify(dataset)
    }
}
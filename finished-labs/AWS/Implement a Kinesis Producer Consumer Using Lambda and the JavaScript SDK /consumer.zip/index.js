const AWS = require('aws-sdk');
const db = new AWS.DynamoDB();

exports.handler = (event) => {
  event.Records.forEach(async function (record) {
    const licensePlate = '';
    const zipCode = '';

    await writeToDB({ zipCode, licensePlate });
  });
};

async function writeToDB({ zipCode, licensePlate }) {
  const params = {
    Item: {
      zipCode: {
        N: zipCode,
      },
      licensePlate: {
        S: licensePlate,
      },
      timeStamp: {
        N: Date.now().toString(),
      },
    },
    TableName: '',
  };

  return db.putItem(params).promise();
}

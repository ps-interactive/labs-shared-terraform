import time
import boto3

from random import randint
from random import choice
import random

def lambda_handler(event, context):
    
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('product_table')
    sequence = ["travel", "bags", "clothing", "electronics", "school", "home"]
    
    for x in sequence:
        # random.shuffle(sequence)
        productId = x
        response = table.put_item(
           Item={
                'productId': productId,
                'title': "This is a promotional product for {}".format(productId),
                'price': randint(10, 200)
            }
        )
    
    return response
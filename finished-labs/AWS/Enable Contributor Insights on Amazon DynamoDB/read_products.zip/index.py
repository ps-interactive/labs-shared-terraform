import boto3

from random import randint
from random import choice
import random

def lambda_handler(event, context):
    
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('product_table')
    sequence = ["travel", "bags", "clothing", "electronics", "school", "home"]
    
    for x in range(1000):
        productId = "school"
        response = table.get_item(Key={'productId': productId})
        
    for x in range(1000):
        productId = choice(sequence[3:])
        response = table.get_item(Key={'productId': productId})
    
    return "done"
    
    
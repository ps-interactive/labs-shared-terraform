let RDS_ENDPOINT= process.env.RDS_ENDPOINT;
RDS_ENDPOINT = RDS_ENDPOINT.substring(0, RDS_ENDPOINT.indexOf(":"));


const mysql = require('serverless-mysql')({
    config: {
      host     :  RDS_ENDPOINT,   // UPDATE THE RDS ENDPOINT
      database : "labdb",
      user     : "labuser",
      password : "LabPass20"
    }
  })

exports.handler = async (event) => {
  

  let create_table = await mysql.query('CREATE TABLE IF NOT EXISTS orders_table (order_id INT AUTO_INCREMENT PRIMARY KEY, product_name text, quantity INT, cost INT)')
  let insert_records = await mysql.query('INSERT INTO orders_table(product_name, quantity, cost) VALUES("books",15, 20)')

  let results = await mysql.query('SELECT * from orders_table')

  // Run clean up function
  await mysql.end()

  // Return the results
  return results
};
import boto3
import uuid
import os
import json
from random import randint
from random import choice
import datetime

kinesis = boto3.client('kinesis')

def clickStreamlogs():
    data = {}
    data['user_id'] = randint(100,600)
    data['device_id'] = choice(['mobile','computer', 'tablet','watch'])
    data['page_name'] = choice(['menu','checkout','product_detail','products','selection','cart'])
    now = datetime.datetime.now()
    str_now = now.isoformat()
    data['client_timestamp'] = str_now
    return data

def lambda_handler(event, context): 
        
        data = json.dumps(clickStreamlogs())
        resp=kinesis.put_record(
                StreamName=os.environ['STREAM_NAME'],
                Data=data,
                PartitionKey=str(uuid.uuid4()))
        print(resp)
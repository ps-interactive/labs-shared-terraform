exports.handler = async (event) => {

    const products = ["Shoes", "Bags", "Sports", "Clothing" ];

    let sampleData;
    const dataset = [];

    for (let i = 0; i < 20; i++) {
        sampleData = {
            "productId": `${Math.random().toString(36).substring(7)}_${Math.random().toString(36).substring(7)}`,
            "product_name": products[Math.floor(Math.random() * products.length)],
            "cost": `$${Math.floor(Math.random() * (100 - 10)) + 10}`,
            "stock": Math.floor(Math.random() * (100 - 10)) + 10        
        }

        dataset.push(sampleData);
    }

    return {
        statusCode: 200,
        body: JSON.stringify(dataset)
    }
}
from flask import Flask, abort, render_template
application = Flask(__name__)

@application.route('/')
def index():
    return render_template('index.html')

@application.route('/400')
def error_400():
    abort(400)

@application.route('/403')
def error_403():
    abort(403)

@application.route('/404')
def error_404():
    abort(404)

@application.route('/405')
def error_405():
    abort(405)

@application.route('/412')
def error_412():
    abort(412)

@application.route('/414')
def error_414():
    abort(414)

@application.route('/415')
def error_415():
    abort(415)

@application.route('/500')
def error_500():
    abort(500)

@application.route('/501')
def error_501():
    abort(501)

@application.route('/502')
def error_502():
    abort(502)

@application.route('/503')
def error_503():
    abort(503)

@application.route('/504')
def error_504():
    abort(504)

if __name__ == '__main__':
    application.run()